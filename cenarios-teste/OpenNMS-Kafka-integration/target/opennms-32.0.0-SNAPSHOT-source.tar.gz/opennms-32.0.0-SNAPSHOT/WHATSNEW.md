[What's New in OpenNMS](docs/modules/releasenotes/pages/whatsnew.adoc)
